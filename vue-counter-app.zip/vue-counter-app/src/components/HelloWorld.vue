<template>
  <div class="counter">
    <h1>Counter App</h1>
    <p>Count: {{ count }}</p>
    <button @click="decrement">Decrement</button>
    <button @click="increment">Increment</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      count: 0,
    };
  },
  methods: {
    increment() {
      this.count++;
    },
    decrement() {
      this.count--;
    },
  },
};
</script>

<style scoped>
.counter {
  text-align: center;
  margin-top: 20px;
}

button {
  font-size: 1.5rem;
  margin: 0 10px;
}
</style>
